<header class="main-header">
  <!--Navbar Bootstrap-->
  <nav class="navbar navbar-expand-lg navbar-light fixed-top">

  <div class="container">
      <a class="navbar-brand" href="{{asset('inicio')}}"><img  class="logo-nav-black" alt="logo"></a>

      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">

        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
            <a class="nav-link" href="{{asset('inicio')}}">INICIO</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="{{asset('galleries')}}">GALERÍA</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="{{asset('pages')}}">ENLACES</a>
          </li>          
          <li class="nav-item">
            <a class="nav-link" href="{{asset('contact')}}">CONTACTO</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
</header>