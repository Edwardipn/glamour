		<!-- FOOTER -->
		<footer>
			<div class="container">
				<div class="footer-widgets">
					<div class="row">
						<div class="col-md-4">
							<div class="foo-block">
								<div class="widget widget-footer ">
									<div class="widget_img">
									<img src="{{asset('img/logos/logo-negras.png')}}" class="logo-footer" alt="logo">
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-4">
							<div class="foo-block">
								<div class="widget widget-footer ">
									<h5 class="widgettitle">Contacto</h5>
									<div class="textwidget">
										<p>Calle República de Honduras 61 INT 8, Col. Centro,<br> Alcaldía Cuauhtémoc, CDMX 06010, México</p>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-4">
							<div class="foo-block foo-last">
								<div class="widget_text widget widget-footer widget_custom_html">
									<div class="textwidget custom-html-widget">
										<p>Tel 55 5772 1398, Cel 55 4200 7997</p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- Copyright -->
				<div class="footer-copyright text-center py-3 text-light">© 2020 Copyright:
					<a href="https://ticdesarrollomag.com.mx/"> ticdesarrollomag</a>
				</div>
  				<!-- Copyright -->
			</div>
		</footer>
		<!-- FOOTER -->