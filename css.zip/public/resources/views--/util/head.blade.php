    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="{{asset('css/bootstrap.min.css')}}" >
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="{{asset('js/jquery-3.5.1.slim.min.js')}}"></script>
    <script src="{{asset('js/popper.min.js')}}"></script>
    <script src="{{asset('js/bootstrap.min.js')}}"></script>

      <!-- Link Swiper's CSS -->
  <link rel="stylesheet" href="{{asset('css/swiper-bundle.min.css')}}">

    <!-- Swiper JS -->
    <script src="{{asset('js/swiper-bundle.min.js')}}"></script>

    <!--Animate CSS-->
    <link rel="stylesheet" href="{{asset('css/animate.min.css')}}">

  <!-- Styles -->
  <link rel="stylesheet" href="{{asset('css/styles.css')}}">
  <!-- Scripts -->
  <!--<script src="{{asset('js/script.js')}}"></script>-->

	<!-- css 	<link type="text/css" media="all" href="{{asset('css/main.css')}}" rel="stylesheet" />-->


	<!-- js -->
	<script type="text/javascript" src="{{asset('js/jquery-1.11.3.min.js')}}"></script>
	<script type="text/javascript" src="{{asset('js/thumb_slider.js')}}"></script>