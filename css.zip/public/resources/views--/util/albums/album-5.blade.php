			<!-- SECTION 2-->
			<section class="section-holder">
				<div class="gallery-container">
					<div class="fullscreen-container fs-gallery">
						<div class="row gallery-holder gallery-grid3cols">
							<div class="col-sm-6 col-lg-4 gallery-post"> <a href="{{asset('img/fotos3/nicol-1.JPG')}}" class="lightbox" title=""> <img class="img-fluid" src="{{asset('img/fotos3/nicol-1.JPG')}}" alt=""> </a></div>
							<div class="col-sm-6 col-lg-4 gallery-post"> <a href="{{asset('img/fotos3/nicol-2.JPG')}}" class="lightbox" title=""> <img class="img-fluid" src="{{asset('img/fotos3/nicol-2.JPG')}}" alt=""> </a></div>
							<div class="col-sm-6 col-lg-4 gallery-post"> <a href="{{asset('img/fotos3/nicol-3.JPG')}}" class="lightbox" title=""> <img class="img-fluid" src="{{asset('img/fotos3/nicol-3.JPG')}}" alt=""> </a></div>
							<div class="col-sm-6 col-lg-4 gallery-post"> <a href="{{asset('img/fotos3/nicol-4.JPG')}}" class="lightbox" title=""> <img class="img-fluid" src="{{asset('img/fotos3/nicol-4.JPG')}}" alt=""> </a></div>
						</div>
					</div>
					<!-- /container -->
				</div>
				<div class="container prev-next-gallery">
					<div class="row meta-nav-holder port-meta-nav">
						<div class="col-md-6 meta-nav">
							<div class="pn-holder">
								<div class="pn-desc">
									<div class="meta-nav-subtitle">
										<h3><a href="#">&larr; Carla &amp; Mike</a></h3>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-6 meta-nav meta-nav-right">
							<div class="pn-holder">
								<div class="pn-desc">
									<div class="meta-nav-subtitle">
										<h3><a href="#">Ellen &amp; James &rarr;</a></h3>
									</div>
								</div>

							</div>
						</div>
					</div>
				</div>
			</section>
			<!-- /SECTION 2-->