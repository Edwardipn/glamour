<!DOCTYPE html>
<html lang="en">

<head>
  @include('util.head')
  <title>Enlaces</title>
</head>

<body>
@include('util.header')
<div class="swiper-slide" style="background-image: url({{asset('img/xv-quinseaneras-6.jpg')}});">
        <div class="carousel-caption d-none d-md-block">
          <h5>Tener quince</h5>
          <p>Tienes en la palma de tu mano la juventud, la belleza, la vida. Disfruta y sé feliz. ¡Felices quince años!</p>
          <!--<p><a class="view-more white-btn" href="#">Más info</a></p>-->
        </div>
      </div>
@include('util.footer')
</body>

</html>