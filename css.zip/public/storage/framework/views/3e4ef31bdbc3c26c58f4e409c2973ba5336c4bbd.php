<!DOCTYPE html>
<html lang="en">

<head>
  <?php echo $__env->make('util.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <title>Albums</title>
</head>

<body>
<?php echo $__env->make('util.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="swiper-slide" style="background-image: url(<?php echo e(asset('img/mission-2.jpg')); ?>);">
        <div class="carousel-caption d-none d-md-block">
          <h5 class="animated zoomIn" style="animation-delay: 1s;">Digital Marketing</h5>
          <p class="animated fadeInLeft" style="animation-delay: 2s;">Lorem ipsum dolor sit amet consectetur adipisicing elit. Atque saepe molestias unde et fugiat corrupti cupiditate?</p>
          <p class="animated zoomIn" style="animation-delay: 3s;"><a class="view-more white-btn" href="#">Find more</a></p>
        </div>
      </div>
<h1>albums</h1>
<?php echo $__env->make('util.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH C:\xampp\htdocs\laravel\glamour\resources\views/albums.blade.php ENDPATH**/ ?>