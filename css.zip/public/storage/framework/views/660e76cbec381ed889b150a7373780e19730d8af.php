<!DOCTYPE html>
<html lang="en">

<head>
  <?php echo $__env->make('util.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <title>Blog</title>
</head>

<body>
<?php echo $__env->make('util.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="swiper-slide" style="background-image: url(<?php echo e(asset('resources/img/services-3.jpg')); ?>);">
        <div class="carousel-caption d-none d-md-block">
          <h5>Unique Moments</h5>
          <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Atque saepe molestias unde et fugiat corrupti cupiditate? Temporibus unde et itaque,</p>
          <p><a class="view-more white-btn" href="#">Find more</a></p>
        </div>
      </div>
<h1>blog</h1>
<?php echo $__env->make('util.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH C:\xampp\htdocs\laravel\glamour\resources\views/blog.blade.php ENDPATH**/ ?>