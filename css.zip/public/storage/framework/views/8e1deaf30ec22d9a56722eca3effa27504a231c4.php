<!DOCTYPE html>
<html lang="en">

<head>
  <?php echo $__env->make('util.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <title>Galería</title>
</head>
<body>

		<!-- PAGE CONTENT -->

		<div class="page-holder custom-page-template page-full fullscreen-page clearfix">
			<!-- SECTION 2-->
			<section class="section-holder-galleries">
				<div class="gallery-container">
					<div class="fullscreen-container fs-gallery">
						<div class="row gallery-holder gallery-grid3cols">
							<div class="col-sm-6 col-lg-4 gallery-post"> <a href="<?php echo e(asset('img/vicky/vicky_730x1095_1.jpg')); ?>" class="lightbox" title=""> <img class="img-fluid" src="<?php echo e(asset('img/vicky/vicky_730x1095_1.jpg')); ?>" alt=""> </a></div>
							<div class="col-sm-6 col-lg-4 gallery-post"> <a href="<?php echo e(asset('img/vicky/vicky_730x1095_2.jpg')); ?>" class="lightbox" title=""> <img class="img-fluid" src="<?php echo e(asset('img/vicky/vicky_730x1095_2.jpg')); ?>" alt=""> </a></div>
							<div class="col-sm-6 col-lg-4 gallery-post"> <a href="<?php echo e(asset('img/vicky/vicky_730x1095_3.jpg')); ?>" class="lightbox" title=""> <img class="img-fluid" src="<?php echo e(asset('img/vicky/vicky_730x1095_3.jpg')); ?>" alt=""> </a></div>
						</div>
					</div>
					<!-- /container -->
				</div>
			</section>
			<!-- /SECTION 2-->
		</div>
		<!-- /PAGE CONTENT -->
	</body>
</html><?php /**PATH /home3/ticdesar/filleafemme.ticdesarrollomag.com.mx/laravel/glamour/resources/views/util/galleries/vicky.blade.php ENDPATH**/ ?>