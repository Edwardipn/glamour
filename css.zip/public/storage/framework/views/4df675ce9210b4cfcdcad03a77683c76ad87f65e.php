<!DOCTYPE html>
<html lang="en">

<head>
  <?php echo $__env->make('util.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <title>Home</title>
</head>

<body>
<?php echo $__env->make('util.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--Swiper Autoplay-->
  <!-- Swiper -->
  <div class="swiper-container">
    <div class="swiper-wrapper">
      <div class="swiper-slide" style="background-image: url(<?php echo e(asset('img/hiking-v1.jpg')); ?>);" >
        <div class="carousel-caption d-none d-md-block">
          <h5 class="animated bounceInRight" style="animation-delay: 1s;">Web Development</h5>
          <p class="animated bounceInLeft" style="animation-delay: 2s;">Atque saepe molestias unde et fugiat corrupti cupiditate? Temporibus unde et itaque, molestiae alias fuga aperiam iure delectus optio ad nesciunt nisi.</p>
          <p class="animated bounceInRight" style="animation-delay: 3s;"><a class="view-more white-btn" href="#">Find more</a></p>
        </div>
      </div>
      <div class="swiper-slide" style="background-image: url(<?php echo e(asset('img/mountain-3.jpg')); ?>);">
        <div class="carousel-caption d-none d-md-block">
          <h5 class="animated slideInDown" style="animation-delay: 1s;">Web Design</h5>
          <p class="animated fadeInUp" style="animation-delay: 2s;">Lorem ipsum dolor sit amet consectetur adipisicing elit. Atque saepe molestias unde et fugiat </p>
          <p class="animated zoomIn" style="animation-delay: 3s;"><a class="view-more white-btn" href="#">Find more</a></p>
        </div>
      </div>
      <div class="swiper-slide" style="background-image: url(<?php echo e(asset('img/mission-2.jpg')); ?>);">
        <div class="carousel-caption d-none d-md-block">
          <h5 class="animated zoomIn" style="animation-delay: 1s;">Digital Marketing</h5>
          <p class="animated fadeInLeft" style="animation-delay: 2s;">Lorem ipsum dolor sit amet consectetur adipisicing elit. Atque saepe molestias unde et fugiat corrupti cupiditate?</p>
          <p class="animated zoomIn" style="animation-delay: 3s;"><a class="view-more white-btn" href="#">Find more</a></p>
        </div>
      </div>
      <div class="swiper-slide" style="background-image: url(<?php echo e(asset('img/walking-v1.jpg')); ?>);">
        <div class="carousel-caption d-none d-md-block">
          <h5>Walking for the adventure</h5>
          <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. </p>
          <p><a class="view-more white-btn" href="#">Find more</a></p>
        </div>
      </div>
    </div>
    <div class="swiper-slide" style="background-image: url(<?php echo e(asset('img/gardening.jpg')); ?>);">
        <div class="carousel-caption d-none d-md-block">
          <h5>Unique Moments</h5>
          <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Atque saepe molestias unde et fugiat corrupti cupiditate? Temporibus unde et itaque,</p>
          <p><a class="view-more white-btn" href="#">Find more</a></p>
        </div>
      </div>
      <div class="swiper-slide" style="background-image: url(<?php echo e(asset('img/services-3.jpg')); ?>);">
        <div class="carousel-caption d-none d-md-block">
          <h5>Unique Moments</h5>
          <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Atque saepe molestias unde et fugiat corrupti cupiditate? Temporibus unde et itaque,</p>
          <p><a class="view-more white-btn" href="#">Find more</a></p>
        </div>
      </div>
    <!-- Add Pagination -->
    <div class="swiper-pagination"></div>
    <!-- Add Arrows -->
    <div class="swiper-button-next"></div>
    <div class="swiper-button-prev"></div>
  </div>

  <div class="text-center topmargin-sm">
    <p>– Adam Sendler</p>
  </div>

  <section id="portfolio">
    <div class="container-fluid">
      <div class="content-center">
          <h2>Lorem ipsum dolor sit amet consectetur adipisicing elit.</h2>
          <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quidem, aliquam? Iure quidem, explicabo obcaecati omnis sequi ullam libero numquam dolor, repellendus rem facilis ducimus voluptatum quia, temporibus quam accusantium fugit.</p>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="portfolio-container">
            <img src="<?php echo e(asset('img/portfolio/camp-1.jpg')); ?>" class="img-fluid" alt="portfolio 1">
            <div class="portfolio-details">
              <div class="content-center">
                <h2>Lorem ipsum dolor sit amet consectetur adipisicing elit.</h2>
                <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quidem, aliquam? Iure quidem, explicabo obcaecati omnis sequi ullam libero numquam dolor, repellendus rem facilis ducimus voluptatum quia, temporibus quam accusantium fugit.</p>
              </div>  
            </div>
          </div>
        </div>
        <div class="col-md-6">
          <div class="portfolio-container">
            <img src="<?php echo e(asset('img/portfolio/camp-2.jpg')); ?>" class="img-fluid" alt="portfolio 2">
            <div class="portfolio-details">
              <div class="content-center">
                <h2>Lorem ipsum dolor sit amet consectetur adipisicing elit.</h2>
                <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quidem, aliquam? Iure quidem, explicabo obcaecati omnis sequi ullam libero numquam dolor, repellendus rem facilis ducimus voluptatum quia, temporibus quam accusantium fugit.</p>
              </div>  
            </div>
          </div>
        </div>
        <div class="col-md-6">
          <div class="portfolio-container">
            <img src="<?php echo e(asset('img/portfolio/camp-3.jpg')); ?>" class="img-fluid" alt="portfolio 3">
            <div class="portfolio-details">
              <div class="content-center">
                <h2>Lorem ipsum dolor sit amet consectetur adipisicing elit.</h2>
                <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quidem, aliquam? Iure quidem, explicabo obcaecati omnis sequi ullam libero numquam dolor, repellendus rem facilis ducimus voluptatum quia, temporibus quam accusantium fugit.</p>
              </div>  
            </div>
          </div>
        </div>
        <div class="col-md-6">
          <div class="portfolio-container">
            <img src="<?php echo e(asset('img/portfolio/camp-4.jpg')); ?>" class="img-fluid" alt="portfolio 4">
            <div class="portfolio-details">
              <div class="content-center">
                <h2>Lorem ipsum dolor sit amet consectetur adipisicing elit.</h2>
                <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quidem, aliquam? Iure quidem, explicabo obcaecati omnis sequi ullam libero numquam dolor, repellendus rem facilis ducimus voluptatum quia, temporibus quam accusantium fugit.</p>
              </div>  
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- Initialize Swiper -->
  <script>
    var swiper = new Swiper('.swiper-container', {
      spaceBetween: 30,
      centeredSlides: true,
      autoplay: {
        delay: 8000,
        disableOnInteraction: false,
      },
      pagination: {
        el: '.swiper-pagination',
        clickable: true,
      },
      navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
      },
    });
  </script>
<!--Swiper Autoplay-->
<?php echo $__env->make('util.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>

<?php /**PATH C:\xampp\htdocs\laravel\glamour\resources\views/index.blade.php ENDPATH**/ ?>