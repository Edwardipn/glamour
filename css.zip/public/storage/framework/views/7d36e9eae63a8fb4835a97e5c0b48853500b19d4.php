<!DOCTYPE html>
<html lang="en">

<head>
  <?php echo $__env->make('util.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <title>Enlaces</title>
</head>

<body>
<?php echo $__env->make('util.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="swiper-slide" style="background-image: url(<?php echo e(asset('img/xv-quinseaneras-6.jpg')); ?>);">
        <div class="carousel-caption d-none d-md-block">
          <h5>Tener quince</h5>
          <p>Tienes en la palma de tu mano la juventud, la belleza, la vida. Disfruta y sé feliz. ¡Felices quince años!</p>
          <!--<p><a class="view-more white-btn" href="#">Más info</a></p>-->
        </div>
      </div>
<?php echo $__env->make('util.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH /home1/filleafe/public_html/public/resources/views/pages.blade.php ENDPATH**/ ?>