    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>" >
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="<?php echo e(asset('js/jquery-3.5.1.slim.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>

      <!-- Link Swiper's CSS -->
  <link rel="stylesheet" href="<?php echo e(asset('css/swiper-bundle.min.css')); ?>">

    <!-- Swiper JS -->
    <script src="<?php echo e(asset('js/swiper-bundle.min.js')); ?>"></script>

    <!--Animate CSS-->
    <link rel="stylesheet" href="<?php echo e(asset('css/animate.min.css')); ?>">

  <!-- Styles -->
  <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>"><?php /**PATH C:\xampp\htdocs\laravel\glamour\resources\views/util/head.blade.php ENDPATH**/ ?>