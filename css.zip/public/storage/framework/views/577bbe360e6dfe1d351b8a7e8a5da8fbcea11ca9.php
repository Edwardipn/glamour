    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>" >
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="<?php echo e(asset('js/jquery-3.5.1.slim.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>

      <!-- Link Swiper's CSS -->
  <link rel="stylesheet" href="<?php echo e(asset('css/swiper-bundle.min.css')); ?>">

    <!-- Swiper JS -->
    <script src="<?php echo e(asset('js/swiper-bundle.min.js')); ?>"></script>

    <!--Animate CSS-->
    <link rel="stylesheet" href="<?php echo e(asset('css/animate.min.css')); ?>">

  <!-- Styles -->
  <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">
  <!-- Scripts -->
  <script src="<?php echo e(asset('js/script.js')); ?>"></script>

	<!-- css 	<link type="text/css" media="all" href="<?php echo e(asset('css/main.css')); ?>" rel="stylesheet" />-->


	<!-- js -->
	<script type="text/javascript" src="<?php echo e(asset('js/jquery-1.11.3.min.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(asset('js/thumb_slider.js')); ?>"></script><?php /**PATH /home1/filleafe/public_html/public/resources/views/util/head.blade.php ENDPATH**/ ?>